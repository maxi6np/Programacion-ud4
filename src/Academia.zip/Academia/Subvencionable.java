package Academia;

public interface Subvencionable {

    double getPrecioSubvencionado();
}
